<div class="container" style="padding:30px;">
        <div class="row"><div class="container" style="padding:30px;">
        <div class="row">This is my textarea to be replaced with CKEditor.</div></div>                        </div></div>