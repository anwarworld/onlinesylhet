<div class="container" style="padding:30px;">
        <div class="row"><div>
        <div><p>this is <b>privacy <i>page</i><i></i></b></p></div></div></div></div>