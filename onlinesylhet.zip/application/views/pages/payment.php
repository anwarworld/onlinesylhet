<div class="container" style="padding:30px;">
        <div class="row"><div>
        <div>This is my textarea to be replaced with <b>CKEditor</b>.</div></div></div></div>