<div class="section-title">
    <h4 class="title">My Accounts</h4>
</div>
<ul class="list-links">
    <li><a href="<?= site_url('users') ?>">Profile</a></li>
    <li><a href="<?= site_url('users/orders') ?>">My Orders</a></li>
    <li><a href="#">My Wishlist</a></li>
    <li><a href="<?= site_url('carts') ?>">My Cart</a></li>
    <li><a href="<?= site_url('users/change_password') ?>">Change Password</a></li>
    <li><a href="<?= site_url('carts/checkout') ?>">Checkout</a></li>
</ul>
