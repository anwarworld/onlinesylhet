<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-13 18:27:24 --> 404 Page Not Found: Login/signout
