<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-04 06:29:36 --> Severity: Warning --> include_once(pages/setting_form.php): failed to open stream: No such file or directory H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php 42
ERROR - 2018-10-04 06:29:36 --> Severity: Warning --> include_once(): Failed opening 'pages/setting_form.php' for inclusion (include_path='H:\xampp\php\PEAR') H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php 42
ERROR - 2018-10-04 06:30:24 --> Severity: Warning --> include_once(pages/setting_form.php): failed to open stream: No such file or directory H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php 42
ERROR - 2018-10-04 06:30:24 --> Severity: Warning --> include_once(): Failed opening 'pages/setting_form.php' for inclusion (include_path='H:\xampp\php\PEAR') H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php 42
ERROR - 2018-10-04 06:30:27 --> Severity: Warning --> include_once(pages/setting_form.php): failed to open stream: No such file or directory H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php 42
ERROR - 2018-10-04 06:30:27 --> Severity: Warning --> include_once(): Failed opening 'pages/setting_form.php' for inclusion (include_path='H:\xampp\php\PEAR') H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php 42
ERROR - 2018-10-04 06:30:41 --> Severity: Warning --> include_once(pages/setting_form.php): failed to open stream: No such file or directory H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php 42
ERROR - 2018-10-04 06:30:41 --> Severity: Warning --> include_once(): Failed opening 'pages/setting_form.php' for inclusion (include_path='H:\xampp\php\PEAR') H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php 42
