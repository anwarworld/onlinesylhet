<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-02 05:19:28 --> Config Class Initialized
INFO - 2018-10-02 05:19:28 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:19:28 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:19:28 --> Utf8 Class Initialized
INFO - 2018-10-02 05:19:28 --> URI Class Initialized
DEBUG - 2018-10-02 05:19:28 --> No URI present. Default controller set.
INFO - 2018-10-02 05:19:28 --> Router Class Initialized
INFO - 2018-10-02 05:19:28 --> Output Class Initialized
INFO - 2018-10-02 05:19:28 --> Security Class Initialized
DEBUG - 2018-10-02 05:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:19:28 --> Input Class Initialized
INFO - 2018-10-02 05:19:28 --> Language Class Initialized
INFO - 2018-10-02 05:19:28 --> Loader Class Initialized
INFO - 2018-10-02 05:19:28 --> Helper loaded: url_helper
INFO - 2018-10-02 05:19:28 --> Helper loaded: common_helper
INFO - 2018-10-02 05:19:28 --> Database Driver Class Initialized
INFO - 2018-10-02 05:19:28 --> Helper loaded: form_helper
INFO - 2018-10-02 05:19:28 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:19:28 --> Controller Class Initialized
INFO - 2018-10-02 05:19:28 --> Config Class Initialized
INFO - 2018-10-02 05:19:28 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:19:29 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:19:29 --> Utf8 Class Initialized
INFO - 2018-10-02 05:19:29 --> URI Class Initialized
INFO - 2018-10-02 05:19:29 --> Router Class Initialized
INFO - 2018-10-02 05:19:29 --> Output Class Initialized
INFO - 2018-10-02 05:19:29 --> Security Class Initialized
DEBUG - 2018-10-02 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:19:29 --> Input Class Initialized
INFO - 2018-10-02 05:19:29 --> Language Class Initialized
INFO - 2018-10-02 05:19:29 --> Loader Class Initialized
INFO - 2018-10-02 05:19:29 --> Helper loaded: url_helper
INFO - 2018-10-02 05:19:29 --> Helper loaded: common_helper
INFO - 2018-10-02 05:19:29 --> Database Driver Class Initialized
INFO - 2018-10-02 05:19:29 --> Helper loaded: form_helper
INFO - 2018-10-02 05:19:29 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:19:29 --> Controller Class Initialized
INFO - 2018-10-02 05:19:29 --> Model "users_mod" initialized
INFO - 2018-10-02 05:19:29 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\login.php
INFO - 2018-10-02 05:19:29 --> Final output sent to browser
DEBUG - 2018-10-02 05:19:29 --> Total execution time: 0.3369
INFO - 2018-10-02 05:19:36 --> Config Class Initialized
INFO - 2018-10-02 05:19:36 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:19:36 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:19:36 --> Utf8 Class Initialized
INFO - 2018-10-02 05:19:36 --> URI Class Initialized
INFO - 2018-10-02 05:19:36 --> Router Class Initialized
INFO - 2018-10-02 05:19:36 --> Output Class Initialized
INFO - 2018-10-02 05:19:36 --> Security Class Initialized
DEBUG - 2018-10-02 05:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:19:36 --> Input Class Initialized
INFO - 2018-10-02 05:19:36 --> Language Class Initialized
INFO - 2018-10-02 05:19:36 --> Loader Class Initialized
INFO - 2018-10-02 05:19:36 --> Helper loaded: url_helper
INFO - 2018-10-02 05:19:36 --> Helper loaded: common_helper
INFO - 2018-10-02 05:19:36 --> Database Driver Class Initialized
INFO - 2018-10-02 05:19:36 --> Helper loaded: form_helper
INFO - 2018-10-02 05:19:36 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:19:36 --> Controller Class Initialized
INFO - 2018-10-02 05:19:36 --> Model "users_mod" initialized
INFO - 2018-10-02 05:19:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 05:19:37 --> Config Class Initialized
INFO - 2018-10-02 05:19:37 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:19:37 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:19:37 --> Utf8 Class Initialized
INFO - 2018-10-02 05:19:37 --> URI Class Initialized
INFO - 2018-10-02 05:19:37 --> Router Class Initialized
INFO - 2018-10-02 05:19:37 --> Output Class Initialized
INFO - 2018-10-02 05:19:37 --> Security Class Initialized
DEBUG - 2018-10-02 05:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:19:37 --> Input Class Initialized
INFO - 2018-10-02 05:19:37 --> Language Class Initialized
INFO - 2018-10-02 05:19:37 --> Loader Class Initialized
INFO - 2018-10-02 05:19:37 --> Helper loaded: url_helper
INFO - 2018-10-02 05:19:37 --> Helper loaded: common_helper
INFO - 2018-10-02 05:19:37 --> Database Driver Class Initialized
INFO - 2018-10-02 05:19:37 --> Helper loaded: form_helper
INFO - 2018-10-02 05:19:37 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:19:37 --> Controller Class Initialized
INFO - 2018-10-02 05:19:37 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 05:19:37 --> Final output sent to browser
DEBUG - 2018-10-02 05:19:37 --> Total execution time: 0.9178
INFO - 2018-10-02 05:19:46 --> Config Class Initialized
INFO - 2018-10-02 05:19:46 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:19:46 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:19:46 --> Utf8 Class Initialized
INFO - 2018-10-02 05:19:46 --> URI Class Initialized
INFO - 2018-10-02 05:19:46 --> Router Class Initialized
INFO - 2018-10-02 05:19:46 --> Output Class Initialized
INFO - 2018-10-02 05:19:46 --> Security Class Initialized
DEBUG - 2018-10-02 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:19:46 --> Input Class Initialized
INFO - 2018-10-02 05:19:46 --> Language Class Initialized
INFO - 2018-10-02 05:19:46 --> Loader Class Initialized
INFO - 2018-10-02 05:19:46 --> Helper loaded: url_helper
INFO - 2018-10-02 05:19:46 --> Helper loaded: common_helper
INFO - 2018-10-02 05:19:46 --> Database Driver Class Initialized
INFO - 2018-10-02 05:19:46 --> Helper loaded: form_helper
INFO - 2018-10-02 05:19:46 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:19:46 --> Controller Class Initialized
INFO - 2018-10-02 05:19:46 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 05:19:46 --> Final output sent to browser
DEBUG - 2018-10-02 05:19:46 --> Total execution time: 0.2099
INFO - 2018-10-02 05:19:53 --> Config Class Initialized
INFO - 2018-10-02 05:19:53 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:19:53 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:19:53 --> Utf8 Class Initialized
INFO - 2018-10-02 05:19:53 --> URI Class Initialized
INFO - 2018-10-02 05:19:53 --> Router Class Initialized
INFO - 2018-10-02 05:19:53 --> Output Class Initialized
INFO - 2018-10-02 05:19:53 --> Security Class Initialized
DEBUG - 2018-10-02 05:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:19:53 --> Input Class Initialized
INFO - 2018-10-02 05:19:53 --> Language Class Initialized
INFO - 2018-10-02 05:19:53 --> Loader Class Initialized
INFO - 2018-10-02 05:19:53 --> Helper loaded: url_helper
INFO - 2018-10-02 05:19:53 --> Helper loaded: common_helper
INFO - 2018-10-02 05:19:53 --> Database Driver Class Initialized
INFO - 2018-10-02 05:19:53 --> Helper loaded: form_helper
INFO - 2018-10-02 05:19:53 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:19:53 --> Controller Class Initialized
INFO - 2018-10-02 05:19:53 --> Helper loaded: file_helper
INFO - 2018-10-02 05:19:53 --> Model "pages_mod" initialized
INFO - 2018-10-02 05:19:53 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 05:19:53 --> Final output sent to browser
DEBUG - 2018-10-02 05:19:53 --> Total execution time: 0.3373
INFO - 2018-10-02 05:19:55 --> Config Class Initialized
INFO - 2018-10-02 05:19:55 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:19:55 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:19:55 --> Utf8 Class Initialized
INFO - 2018-10-02 05:19:55 --> URI Class Initialized
INFO - 2018-10-02 05:19:55 --> Router Class Initialized
INFO - 2018-10-02 05:19:55 --> Output Class Initialized
INFO - 2018-10-02 05:19:55 --> Security Class Initialized
DEBUG - 2018-10-02 05:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:19:55 --> Input Class Initialized
INFO - 2018-10-02 05:19:55 --> Language Class Initialized
INFO - 2018-10-02 05:19:55 --> Loader Class Initialized
INFO - 2018-10-02 05:19:55 --> Helper loaded: url_helper
INFO - 2018-10-02 05:19:55 --> Helper loaded: common_helper
INFO - 2018-10-02 05:19:55 --> Database Driver Class Initialized
INFO - 2018-10-02 05:19:55 --> Helper loaded: form_helper
INFO - 2018-10-02 05:19:55 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:19:55 --> Controller Class Initialized
INFO - 2018-10-02 05:19:55 --> Model "sliders_mod" initialized
INFO - 2018-10-02 05:19:55 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 05:19:55 --> Final output sent to browser
DEBUG - 2018-10-02 05:19:55 --> Total execution time: 0.3765
INFO - 2018-10-02 05:20:48 --> Config Class Initialized
INFO - 2018-10-02 05:20:48 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:20:48 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:20:48 --> Utf8 Class Initialized
INFO - 2018-10-02 05:20:48 --> URI Class Initialized
INFO - 2018-10-02 05:20:48 --> Router Class Initialized
INFO - 2018-10-02 05:20:48 --> Output Class Initialized
INFO - 2018-10-02 05:20:48 --> Security Class Initialized
DEBUG - 2018-10-02 05:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:20:48 --> Input Class Initialized
INFO - 2018-10-02 05:20:48 --> Language Class Initialized
INFO - 2018-10-02 05:20:48 --> Loader Class Initialized
INFO - 2018-10-02 05:20:48 --> Helper loaded: url_helper
INFO - 2018-10-02 05:20:48 --> Helper loaded: common_helper
INFO - 2018-10-02 05:20:48 --> Database Driver Class Initialized
INFO - 2018-10-02 05:20:48 --> Helper loaded: form_helper
INFO - 2018-10-02 05:20:48 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:20:48 --> Controller Class Initialized
INFO - 2018-10-02 05:20:48 --> Model "sliders_mod" initialized
INFO - 2018-10-02 05:20:48 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 05:20:48 --> Final output sent to browser
DEBUG - 2018-10-02 05:20:48 --> Total execution time: 0.2278
INFO - 2018-10-02 05:20:56 --> Config Class Initialized
INFO - 2018-10-02 05:20:56 --> Hooks Class Initialized
DEBUG - 2018-10-02 05:20:56 --> UTF-8 Support Enabled
INFO - 2018-10-02 05:20:56 --> Utf8 Class Initialized
INFO - 2018-10-02 05:20:56 --> URI Class Initialized
INFO - 2018-10-02 05:20:56 --> Router Class Initialized
INFO - 2018-10-02 05:20:56 --> Output Class Initialized
INFO - 2018-10-02 05:20:56 --> Security Class Initialized
DEBUG - 2018-10-02 05:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 05:20:56 --> Input Class Initialized
INFO - 2018-10-02 05:20:56 --> Language Class Initialized
INFO - 2018-10-02 05:20:56 --> Loader Class Initialized
INFO - 2018-10-02 05:20:56 --> Helper loaded: url_helper
INFO - 2018-10-02 05:20:56 --> Helper loaded: common_helper
INFO - 2018-10-02 05:20:56 --> Database Driver Class Initialized
INFO - 2018-10-02 05:20:56 --> Helper loaded: form_helper
INFO - 2018-10-02 05:20:56 --> Form Validation Class Initialized
DEBUG - 2018-10-02 05:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 05:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 05:20:56 --> Controller Class Initialized
INFO - 2018-10-02 05:20:56 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 05:20:56 --> Final output sent to browser
DEBUG - 2018-10-02 05:20:56 --> Total execution time: 0.2231
INFO - 2018-10-02 06:02:21 --> Config Class Initialized
INFO - 2018-10-02 06:02:21 --> Hooks Class Initialized
DEBUG - 2018-10-02 06:02:21 --> UTF-8 Support Enabled
INFO - 2018-10-02 06:02:21 --> Utf8 Class Initialized
INFO - 2018-10-02 06:02:21 --> URI Class Initialized
INFO - 2018-10-02 06:02:21 --> Router Class Initialized
INFO - 2018-10-02 06:02:21 --> Output Class Initialized
INFO - 2018-10-02 06:02:21 --> Security Class Initialized
DEBUG - 2018-10-02 06:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 06:02:21 --> Input Class Initialized
INFO - 2018-10-02 06:02:21 --> Language Class Initialized
INFO - 2018-10-02 06:02:21 --> Loader Class Initialized
INFO - 2018-10-02 06:02:21 --> Helper loaded: url_helper
INFO - 2018-10-02 06:02:21 --> Helper loaded: common_helper
INFO - 2018-10-02 06:02:21 --> Database Driver Class Initialized
INFO - 2018-10-02 06:02:21 --> Helper loaded: form_helper
INFO - 2018-10-02 06:02:21 --> Form Validation Class Initialized
DEBUG - 2018-10-02 06:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 06:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 06:02:21 --> Controller Class Initialized
INFO - 2018-10-02 06:02:21 --> Config Class Initialized
INFO - 2018-10-02 06:02:21 --> Hooks Class Initialized
DEBUG - 2018-10-02 06:02:21 --> UTF-8 Support Enabled
INFO - 2018-10-02 06:02:21 --> Utf8 Class Initialized
INFO - 2018-10-02 06:02:21 --> URI Class Initialized
INFO - 2018-10-02 06:02:21 --> Router Class Initialized
INFO - 2018-10-02 06:02:21 --> Output Class Initialized
INFO - 2018-10-02 06:02:21 --> Security Class Initialized
DEBUG - 2018-10-02 06:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 06:02:21 --> Input Class Initialized
INFO - 2018-10-02 06:02:21 --> Language Class Initialized
INFO - 2018-10-02 06:02:21 --> Loader Class Initialized
INFO - 2018-10-02 06:02:21 --> Helper loaded: url_helper
INFO - 2018-10-02 06:02:21 --> Helper loaded: common_helper
INFO - 2018-10-02 06:02:21 --> Database Driver Class Initialized
INFO - 2018-10-02 06:02:21 --> Helper loaded: form_helper
INFO - 2018-10-02 06:02:21 --> Form Validation Class Initialized
DEBUG - 2018-10-02 06:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 06:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 06:02:21 --> Controller Class Initialized
INFO - 2018-10-02 06:02:21 --> Model "users_mod" initialized
INFO - 2018-10-02 06:02:21 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\login.php
INFO - 2018-10-02 06:02:21 --> Final output sent to browser
DEBUG - 2018-10-02 06:02:21 --> Total execution time: 0.2652
INFO - 2018-10-02 07:23:29 --> Config Class Initialized
INFO - 2018-10-02 07:23:29 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:23:29 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:23:29 --> Utf8 Class Initialized
INFO - 2018-10-02 07:23:29 --> URI Class Initialized
INFO - 2018-10-02 07:23:29 --> Router Class Initialized
INFO - 2018-10-02 07:23:29 --> Output Class Initialized
INFO - 2018-10-02 07:23:29 --> Security Class Initialized
DEBUG - 2018-10-02 07:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:23:29 --> Input Class Initialized
INFO - 2018-10-02 07:23:29 --> Language Class Initialized
INFO - 2018-10-02 07:23:29 --> Loader Class Initialized
INFO - 2018-10-02 07:23:29 --> Helper loaded: url_helper
INFO - 2018-10-02 07:23:29 --> Helper loaded: common_helper
INFO - 2018-10-02 07:23:29 --> Database Driver Class Initialized
INFO - 2018-10-02 07:23:29 --> Helper loaded: form_helper
INFO - 2018-10-02 07:23:29 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:23:29 --> Controller Class Initialized
INFO - 2018-10-02 07:23:29 --> Model "users_mod" initialized
INFO - 2018-10-02 07:23:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 07:23:29 --> Config Class Initialized
INFO - 2018-10-02 07:23:29 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:23:29 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:23:29 --> Utf8 Class Initialized
INFO - 2018-10-02 07:23:29 --> URI Class Initialized
INFO - 2018-10-02 07:23:29 --> Router Class Initialized
INFO - 2018-10-02 07:23:29 --> Output Class Initialized
INFO - 2018-10-02 07:23:29 --> Security Class Initialized
DEBUG - 2018-10-02 07:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:23:29 --> Input Class Initialized
INFO - 2018-10-02 07:23:29 --> Language Class Initialized
INFO - 2018-10-02 07:23:29 --> Loader Class Initialized
INFO - 2018-10-02 07:23:29 --> Helper loaded: url_helper
INFO - 2018-10-02 07:23:29 --> Helper loaded: common_helper
INFO - 2018-10-02 07:23:29 --> Database Driver Class Initialized
INFO - 2018-10-02 07:23:29 --> Helper loaded: form_helper
INFO - 2018-10-02 07:23:29 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:23:29 --> Controller Class Initialized
INFO - 2018-10-02 07:23:30 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:23:30 --> Final output sent to browser
DEBUG - 2018-10-02 07:23:30 --> Total execution time: 0.3534
INFO - 2018-10-02 07:27:16 --> Config Class Initialized
INFO - 2018-10-02 07:27:16 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:27:16 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:27:16 --> Utf8 Class Initialized
INFO - 2018-10-02 07:27:16 --> URI Class Initialized
INFO - 2018-10-02 07:27:16 --> Router Class Initialized
INFO - 2018-10-02 07:27:16 --> Output Class Initialized
INFO - 2018-10-02 07:27:16 --> Security Class Initialized
DEBUG - 2018-10-02 07:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:27:16 --> Input Class Initialized
INFO - 2018-10-02 07:27:16 --> Language Class Initialized
INFO - 2018-10-02 07:27:16 --> Loader Class Initialized
INFO - 2018-10-02 07:27:16 --> Helper loaded: url_helper
INFO - 2018-10-02 07:27:16 --> Helper loaded: common_helper
INFO - 2018-10-02 07:27:16 --> Database Driver Class Initialized
INFO - 2018-10-02 07:27:16 --> Helper loaded: form_helper
INFO - 2018-10-02 07:27:16 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:27:16 --> Controller Class Initialized
INFO - 2018-10-02 07:27:16 --> Config Class Initialized
INFO - 2018-10-02 07:27:16 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:27:16 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:27:16 --> Utf8 Class Initialized
INFO - 2018-10-02 07:27:16 --> URI Class Initialized
INFO - 2018-10-02 07:27:16 --> Router Class Initialized
INFO - 2018-10-02 07:27:16 --> Output Class Initialized
INFO - 2018-10-02 07:27:16 --> Security Class Initialized
DEBUG - 2018-10-02 07:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:27:16 --> Input Class Initialized
INFO - 2018-10-02 07:27:16 --> Language Class Initialized
INFO - 2018-10-02 07:27:16 --> Loader Class Initialized
INFO - 2018-10-02 07:27:16 --> Helper loaded: url_helper
INFO - 2018-10-02 07:27:16 --> Helper loaded: common_helper
INFO - 2018-10-02 07:27:16 --> Database Driver Class Initialized
INFO - 2018-10-02 07:27:16 --> Helper loaded: form_helper
INFO - 2018-10-02 07:27:16 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:27:16 --> Controller Class Initialized
INFO - 2018-10-02 07:27:17 --> Model "users_mod" initialized
INFO - 2018-10-02 07:27:17 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\login.php
INFO - 2018-10-02 07:27:17 --> Final output sent to browser
DEBUG - 2018-10-02 07:27:17 --> Total execution time: 0.2635
INFO - 2018-10-02 07:29:33 --> Config Class Initialized
INFO - 2018-10-02 07:29:33 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:29:33 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:29:33 --> Utf8 Class Initialized
INFO - 2018-10-02 07:29:33 --> URI Class Initialized
INFO - 2018-10-02 07:29:33 --> Router Class Initialized
INFO - 2018-10-02 07:29:33 --> Output Class Initialized
INFO - 2018-10-02 07:29:33 --> Security Class Initialized
DEBUG - 2018-10-02 07:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:29:33 --> Input Class Initialized
INFO - 2018-10-02 07:29:33 --> Language Class Initialized
INFO - 2018-10-02 07:29:33 --> Loader Class Initialized
INFO - 2018-10-02 07:29:33 --> Helper loaded: url_helper
INFO - 2018-10-02 07:29:33 --> Helper loaded: common_helper
INFO - 2018-10-02 07:29:33 --> Database Driver Class Initialized
INFO - 2018-10-02 07:29:33 --> Helper loaded: form_helper
INFO - 2018-10-02 07:29:33 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:29:33 --> Controller Class Initialized
INFO - 2018-10-02 07:29:33 --> Model "users_mod" initialized
INFO - 2018-10-02 07:29:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 07:29:33 --> Config Class Initialized
INFO - 2018-10-02 07:29:33 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:29:33 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:29:33 --> Utf8 Class Initialized
INFO - 2018-10-02 07:29:33 --> URI Class Initialized
INFO - 2018-10-02 07:29:33 --> Router Class Initialized
INFO - 2018-10-02 07:29:33 --> Output Class Initialized
INFO - 2018-10-02 07:29:33 --> Security Class Initialized
DEBUG - 2018-10-02 07:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:29:33 --> Input Class Initialized
INFO - 2018-10-02 07:29:33 --> Language Class Initialized
INFO - 2018-10-02 07:29:33 --> Loader Class Initialized
INFO - 2018-10-02 07:29:33 --> Helper loaded: url_helper
INFO - 2018-10-02 07:29:33 --> Helper loaded: common_helper
INFO - 2018-10-02 07:29:33 --> Database Driver Class Initialized
INFO - 2018-10-02 07:29:33 --> Helper loaded: form_helper
INFO - 2018-10-02 07:29:33 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:29:33 --> Controller Class Initialized
INFO - 2018-10-02 07:29:33 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:29:33 --> Final output sent to browser
DEBUG - 2018-10-02 07:29:33 --> Total execution time: 0.2131
INFO - 2018-10-02 07:41:48 --> Config Class Initialized
INFO - 2018-10-02 07:41:48 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:41:48 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:41:48 --> Utf8 Class Initialized
INFO - 2018-10-02 07:41:48 --> URI Class Initialized
INFO - 2018-10-02 07:41:49 --> Router Class Initialized
INFO - 2018-10-02 07:41:49 --> Output Class Initialized
INFO - 2018-10-02 07:41:49 --> Security Class Initialized
DEBUG - 2018-10-02 07:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:41:49 --> Input Class Initialized
INFO - 2018-10-02 07:41:49 --> Language Class Initialized
INFO - 2018-10-02 07:41:49 --> Loader Class Initialized
INFO - 2018-10-02 07:41:49 --> Helper loaded: url_helper
INFO - 2018-10-02 07:41:49 --> Helper loaded: common_helper
INFO - 2018-10-02 07:41:49 --> Database Driver Class Initialized
INFO - 2018-10-02 07:41:49 --> Helper loaded: form_helper
INFO - 2018-10-02 07:41:49 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:41:49 --> Controller Class Initialized
INFO - 2018-10-02 07:41:49 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:41:49 --> Final output sent to browser
DEBUG - 2018-10-02 07:41:49 --> Total execution time: 0.2539
INFO - 2018-10-02 07:41:50 --> Config Class Initialized
INFO - 2018-10-02 07:41:50 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:41:50 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:41:50 --> Utf8 Class Initialized
INFO - 2018-10-02 07:41:50 --> URI Class Initialized
DEBUG - 2018-10-02 07:41:50 --> No URI present. Default controller set.
INFO - 2018-10-02 07:41:50 --> Router Class Initialized
INFO - 2018-10-02 07:41:50 --> Output Class Initialized
INFO - 2018-10-02 07:41:50 --> Security Class Initialized
DEBUG - 2018-10-02 07:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:41:50 --> Input Class Initialized
INFO - 2018-10-02 07:41:50 --> Language Class Initialized
INFO - 2018-10-02 07:41:50 --> Loader Class Initialized
INFO - 2018-10-02 07:41:50 --> Helper loaded: url_helper
INFO - 2018-10-02 07:41:51 --> Helper loaded: common_helper
INFO - 2018-10-02 07:41:51 --> Database Driver Class Initialized
INFO - 2018-10-02 07:41:51 --> Helper loaded: form_helper
INFO - 2018-10-02 07:41:51 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:41:51 --> Controller Class Initialized
INFO - 2018-10-02 07:41:51 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:41:51 --> Final output sent to browser
DEBUG - 2018-10-02 07:41:51 --> Total execution time: 0.4224
INFO - 2018-10-02 07:41:52 --> Config Class Initialized
INFO - 2018-10-02 07:41:52 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:41:52 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:41:52 --> Utf8 Class Initialized
INFO - 2018-10-02 07:41:52 --> URI Class Initialized
INFO - 2018-10-02 07:41:52 --> Router Class Initialized
INFO - 2018-10-02 07:41:52 --> Output Class Initialized
INFO - 2018-10-02 07:41:52 --> Security Class Initialized
DEBUG - 2018-10-02 07:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:41:52 --> Input Class Initialized
INFO - 2018-10-02 07:41:52 --> Language Class Initialized
INFO - 2018-10-02 07:41:52 --> Loader Class Initialized
INFO - 2018-10-02 07:41:52 --> Helper loaded: url_helper
INFO - 2018-10-02 07:41:52 --> Helper loaded: common_helper
INFO - 2018-10-02 07:41:52 --> Database Driver Class Initialized
INFO - 2018-10-02 07:41:52 --> Helper loaded: form_helper
INFO - 2018-10-02 07:41:52 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:41:52 --> Controller Class Initialized
INFO - 2018-10-02 07:41:52 --> Model "products_mod" initialized
INFO - 2018-10-02 07:41:52 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:41:52 --> Final output sent to browser
DEBUG - 2018-10-02 07:41:53 --> Total execution time: 0.6122
INFO - 2018-10-02 07:41:56 --> Config Class Initialized
INFO - 2018-10-02 07:41:56 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:41:56 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:41:56 --> Utf8 Class Initialized
INFO - 2018-10-02 07:41:56 --> URI Class Initialized
INFO - 2018-10-02 07:41:56 --> Router Class Initialized
INFO - 2018-10-02 07:41:56 --> Output Class Initialized
INFO - 2018-10-02 07:41:56 --> Security Class Initialized
DEBUG - 2018-10-02 07:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:41:56 --> Input Class Initialized
INFO - 2018-10-02 07:41:56 --> Language Class Initialized
INFO - 2018-10-02 07:41:56 --> Loader Class Initialized
INFO - 2018-10-02 07:41:56 --> Helper loaded: url_helper
INFO - 2018-10-02 07:41:56 --> Helper loaded: common_helper
INFO - 2018-10-02 07:41:56 --> Database Driver Class Initialized
INFO - 2018-10-02 07:41:56 --> Helper loaded: form_helper
INFO - 2018-10-02 07:41:56 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:41:56 --> Controller Class Initialized
INFO - 2018-10-02 07:41:56 --> Model "products_mod" initialized
INFO - 2018-10-02 07:41:56 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:41:56 --> Final output sent to browser
DEBUG - 2018-10-02 07:41:56 --> Total execution time: 0.2647
INFO - 2018-10-02 07:41:58 --> Config Class Initialized
INFO - 2018-10-02 07:41:58 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:41:58 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:41:58 --> Utf8 Class Initialized
INFO - 2018-10-02 07:41:58 --> URI Class Initialized
INFO - 2018-10-02 07:41:58 --> Router Class Initialized
INFO - 2018-10-02 07:41:58 --> Output Class Initialized
INFO - 2018-10-02 07:41:58 --> Security Class Initialized
DEBUG - 2018-10-02 07:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:41:58 --> Input Class Initialized
INFO - 2018-10-02 07:41:58 --> Language Class Initialized
INFO - 2018-10-02 07:41:58 --> Loader Class Initialized
INFO - 2018-10-02 07:41:58 --> Helper loaded: url_helper
INFO - 2018-10-02 07:41:59 --> Helper loaded: common_helper
INFO - 2018-10-02 07:41:59 --> Database Driver Class Initialized
INFO - 2018-10-02 07:41:59 --> Helper loaded: form_helper
INFO - 2018-10-02 07:41:59 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:41:59 --> Controller Class Initialized
INFO - 2018-10-02 07:41:59 --> Model "products_mod" initialized
INFO - 2018-10-02 07:41:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 07:41:59 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:41:59 --> Final output sent to browser
DEBUG - 2018-10-02 07:41:59 --> Total execution time: 0.2822
INFO - 2018-10-02 07:42:02 --> Config Class Initialized
INFO - 2018-10-02 07:42:02 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:42:02 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:42:02 --> Utf8 Class Initialized
INFO - 2018-10-02 07:42:02 --> URI Class Initialized
INFO - 2018-10-02 07:42:02 --> Router Class Initialized
INFO - 2018-10-02 07:42:02 --> Output Class Initialized
INFO - 2018-10-02 07:42:02 --> Security Class Initialized
DEBUG - 2018-10-02 07:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:42:02 --> Input Class Initialized
INFO - 2018-10-02 07:42:02 --> Language Class Initialized
INFO - 2018-10-02 07:42:02 --> Loader Class Initialized
INFO - 2018-10-02 07:42:02 --> Helper loaded: url_helper
INFO - 2018-10-02 07:42:02 --> Helper loaded: common_helper
INFO - 2018-10-02 07:42:02 --> Database Driver Class Initialized
INFO - 2018-10-02 07:42:02 --> Helper loaded: form_helper
INFO - 2018-10-02 07:42:02 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:42:02 --> Controller Class Initialized
INFO - 2018-10-02 07:42:02 --> Model "products_mod" initialized
INFO - 2018-10-02 07:42:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 07:42:02 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:42:02 --> Final output sent to browser
DEBUG - 2018-10-02 07:42:02 --> Total execution time: 0.2743
INFO - 2018-10-02 07:59:20 --> Config Class Initialized
INFO - 2018-10-02 07:59:20 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:59:20 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:59:20 --> Utf8 Class Initialized
INFO - 2018-10-02 07:59:20 --> URI Class Initialized
INFO - 2018-10-02 07:59:20 --> Router Class Initialized
INFO - 2018-10-02 07:59:20 --> Output Class Initialized
INFO - 2018-10-02 07:59:20 --> Security Class Initialized
DEBUG - 2018-10-02 07:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:59:20 --> Input Class Initialized
INFO - 2018-10-02 07:59:20 --> Language Class Initialized
INFO - 2018-10-02 07:59:20 --> Loader Class Initialized
INFO - 2018-10-02 07:59:20 --> Helper loaded: url_helper
INFO - 2018-10-02 07:59:20 --> Helper loaded: common_helper
INFO - 2018-10-02 07:59:20 --> Database Driver Class Initialized
INFO - 2018-10-02 07:59:20 --> Helper loaded: form_helper
INFO - 2018-10-02 07:59:20 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:59:20 --> Controller Class Initialized
INFO - 2018-10-02 07:59:20 --> Config Class Initialized
INFO - 2018-10-02 07:59:20 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:59:20 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:59:20 --> Utf8 Class Initialized
INFO - 2018-10-02 07:59:20 --> URI Class Initialized
INFO - 2018-10-02 07:59:20 --> Router Class Initialized
INFO - 2018-10-02 07:59:20 --> Output Class Initialized
INFO - 2018-10-02 07:59:20 --> Security Class Initialized
DEBUG - 2018-10-02 07:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:59:20 --> Input Class Initialized
INFO - 2018-10-02 07:59:20 --> Language Class Initialized
INFO - 2018-10-02 07:59:20 --> Loader Class Initialized
INFO - 2018-10-02 07:59:20 --> Helper loaded: url_helper
INFO - 2018-10-02 07:59:20 --> Helper loaded: common_helper
INFO - 2018-10-02 07:59:20 --> Database Driver Class Initialized
INFO - 2018-10-02 07:59:20 --> Helper loaded: form_helper
INFO - 2018-10-02 07:59:20 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:59:20 --> Controller Class Initialized
INFO - 2018-10-02 07:59:20 --> Model "users_mod" initialized
INFO - 2018-10-02 07:59:20 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\login.php
INFO - 2018-10-02 07:59:20 --> Final output sent to browser
DEBUG - 2018-10-02 07:59:20 --> Total execution time: 0.2365
INFO - 2018-10-02 07:59:32 --> Config Class Initialized
INFO - 2018-10-02 07:59:32 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:59:32 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:59:32 --> Utf8 Class Initialized
INFO - 2018-10-02 07:59:32 --> URI Class Initialized
INFO - 2018-10-02 07:59:32 --> Router Class Initialized
INFO - 2018-10-02 07:59:32 --> Output Class Initialized
INFO - 2018-10-02 07:59:32 --> Security Class Initialized
DEBUG - 2018-10-02 07:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:59:32 --> Input Class Initialized
INFO - 2018-10-02 07:59:32 --> Language Class Initialized
INFO - 2018-10-02 07:59:32 --> Loader Class Initialized
INFO - 2018-10-02 07:59:32 --> Helper loaded: url_helper
INFO - 2018-10-02 07:59:32 --> Helper loaded: common_helper
INFO - 2018-10-02 07:59:32 --> Database Driver Class Initialized
INFO - 2018-10-02 07:59:32 --> Helper loaded: form_helper
INFO - 2018-10-02 07:59:32 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:59:32 --> Controller Class Initialized
INFO - 2018-10-02 07:59:32 --> Model "users_mod" initialized
INFO - 2018-10-02 07:59:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 07:59:32 --> Config Class Initialized
INFO - 2018-10-02 07:59:32 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:59:32 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:59:32 --> Utf8 Class Initialized
INFO - 2018-10-02 07:59:32 --> URI Class Initialized
INFO - 2018-10-02 07:59:32 --> Router Class Initialized
INFO - 2018-10-02 07:59:32 --> Output Class Initialized
INFO - 2018-10-02 07:59:32 --> Security Class Initialized
DEBUG - 2018-10-02 07:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:59:32 --> Input Class Initialized
INFO - 2018-10-02 07:59:32 --> Language Class Initialized
INFO - 2018-10-02 07:59:32 --> Loader Class Initialized
INFO - 2018-10-02 07:59:32 --> Helper loaded: url_helper
INFO - 2018-10-02 07:59:32 --> Helper loaded: common_helper
INFO - 2018-10-02 07:59:32 --> Database Driver Class Initialized
INFO - 2018-10-02 07:59:32 --> Helper loaded: form_helper
INFO - 2018-10-02 07:59:32 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:59:32 --> Controller Class Initialized
INFO - 2018-10-02 07:59:32 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:59:32 --> Final output sent to browser
DEBUG - 2018-10-02 07:59:32 --> Total execution time: 0.2233
INFO - 2018-10-02 07:59:34 --> Config Class Initialized
INFO - 2018-10-02 07:59:34 --> Hooks Class Initialized
DEBUG - 2018-10-02 07:59:34 --> UTF-8 Support Enabled
INFO - 2018-10-02 07:59:34 --> Utf8 Class Initialized
INFO - 2018-10-02 07:59:34 --> URI Class Initialized
INFO - 2018-10-02 07:59:34 --> Router Class Initialized
INFO - 2018-10-02 07:59:34 --> Output Class Initialized
INFO - 2018-10-02 07:59:34 --> Security Class Initialized
DEBUG - 2018-10-02 07:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 07:59:34 --> Input Class Initialized
INFO - 2018-10-02 07:59:34 --> Language Class Initialized
INFO - 2018-10-02 07:59:34 --> Loader Class Initialized
INFO - 2018-10-02 07:59:34 --> Helper loaded: url_helper
INFO - 2018-10-02 07:59:34 --> Helper loaded: common_helper
INFO - 2018-10-02 07:59:34 --> Database Driver Class Initialized
INFO - 2018-10-02 07:59:34 --> Helper loaded: form_helper
INFO - 2018-10-02 07:59:34 --> Form Validation Class Initialized
DEBUG - 2018-10-02 07:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 07:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 07:59:34 --> Controller Class Initialized
INFO - 2018-10-02 07:59:34 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 07:59:34 --> Final output sent to browser
DEBUG - 2018-10-02 07:59:34 --> Total execution time: 0.2427
INFO - 2018-10-02 08:14:52 --> Config Class Initialized
INFO - 2018-10-02 08:14:52 --> Hooks Class Initialized
DEBUG - 2018-10-02 08:14:52 --> UTF-8 Support Enabled
INFO - 2018-10-02 08:14:52 --> Utf8 Class Initialized
INFO - 2018-10-02 08:14:52 --> URI Class Initialized
INFO - 2018-10-02 08:14:52 --> Router Class Initialized
INFO - 2018-10-02 08:14:52 --> Output Class Initialized
INFO - 2018-10-02 08:14:52 --> Security Class Initialized
DEBUG - 2018-10-02 08:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 08:14:52 --> Input Class Initialized
INFO - 2018-10-02 08:14:52 --> Language Class Initialized
INFO - 2018-10-02 08:14:52 --> Loader Class Initialized
INFO - 2018-10-02 08:14:52 --> Helper loaded: url_helper
INFO - 2018-10-02 08:14:52 --> Helper loaded: common_helper
INFO - 2018-10-02 08:14:52 --> Database Driver Class Initialized
INFO - 2018-10-02 08:14:52 --> Helper loaded: form_helper
INFO - 2018-10-02 08:14:52 --> Form Validation Class Initialized
DEBUG - 2018-10-02 08:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 08:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 08:14:52 --> Controller Class Initialized
INFO - 2018-10-02 08:14:52 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 08:14:52 --> Final output sent to browser
DEBUG - 2018-10-02 08:14:52 --> Total execution time: 0.3060
INFO - 2018-10-02 08:14:56 --> Config Class Initialized
INFO - 2018-10-02 08:14:56 --> Hooks Class Initialized
DEBUG - 2018-10-02 08:14:56 --> UTF-8 Support Enabled
INFO - 2018-10-02 08:14:56 --> Utf8 Class Initialized
INFO - 2018-10-02 08:14:56 --> URI Class Initialized
INFO - 2018-10-02 08:14:56 --> Router Class Initialized
INFO - 2018-10-02 08:14:56 --> Output Class Initialized
INFO - 2018-10-02 08:14:56 --> Security Class Initialized
DEBUG - 2018-10-02 08:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 08:14:56 --> Input Class Initialized
INFO - 2018-10-02 08:14:56 --> Language Class Initialized
INFO - 2018-10-02 08:14:56 --> Loader Class Initialized
INFO - 2018-10-02 08:14:56 --> Helper loaded: url_helper
INFO - 2018-10-02 08:14:56 --> Helper loaded: common_helper
INFO - 2018-10-02 08:14:56 --> Database Driver Class Initialized
INFO - 2018-10-02 08:14:56 --> Helper loaded: form_helper
INFO - 2018-10-02 08:14:56 --> Form Validation Class Initialized
DEBUG - 2018-10-02 08:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 08:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 08:14:56 --> Controller Class Initialized
INFO - 2018-10-02 08:14:56 --> Model "products_mod" initialized
INFO - 2018-10-02 08:14:56 --> File loaded: H:\xampp\htdocs\cms\admin\application\views\main.php
INFO - 2018-10-02 08:14:56 --> Final output sent to browser
DEBUG - 2018-10-02 08:14:56 --> Total execution time: 0.3031
INFO - 2018-10-02 08:56:31 --> Config Class Initialized
INFO - 2018-10-02 08:56:32 --> Hooks Class Initialized
DEBUG - 2018-10-02 08:56:32 --> UTF-8 Support Enabled
INFO - 2018-10-02 08:56:32 --> Utf8 Class Initialized
INFO - 2018-10-02 08:56:32 --> URI Class Initialized
INFO - 2018-10-02 08:56:32 --> Router Class Initialized
INFO - 2018-10-02 08:56:32 --> Output Class Initialized
INFO - 2018-10-02 08:56:32 --> Security Class Initialized
DEBUG - 2018-10-02 08:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 08:56:32 --> Input Class Initialized
INFO - 2018-10-02 08:56:32 --> Language Class Initialized
INFO - 2018-10-02 08:56:32 --> Loader Class Initialized
INFO - 2018-10-02 08:56:32 --> Helper loaded: url_helper
INFO - 2018-10-02 08:56:32 --> Helper loaded: common_helper
INFO - 2018-10-02 08:56:32 --> Database Driver Class Initialized
INFO - 2018-10-02 08:56:32 --> Helper loaded: form_helper
INFO - 2018-10-02 08:56:32 --> Form Validation Class Initialized
DEBUG - 2018-10-02 08:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 08:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 08:56:32 --> Controller Class Initialized
INFO - 2018-10-02 08:56:32 --> Model "products_mod" initialized
INFO - 2018-10-02 08:56:32 --> File loaded: H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php
INFO - 2018-10-02 08:56:32 --> Final output sent to browser
DEBUG - 2018-10-02 08:56:32 --> Total execution time: 0.2697
INFO - 2018-10-02 08:56:34 --> Config Class Initialized
INFO - 2018-10-02 08:56:34 --> Hooks Class Initialized
DEBUG - 2018-10-02 08:56:34 --> UTF-8 Support Enabled
INFO - 2018-10-02 08:56:34 --> Utf8 Class Initialized
INFO - 2018-10-02 08:56:34 --> URI Class Initialized
INFO - 2018-10-02 08:56:34 --> Router Class Initialized
INFO - 2018-10-02 08:56:34 --> Output Class Initialized
INFO - 2018-10-02 08:56:34 --> Security Class Initialized
DEBUG - 2018-10-02 08:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 08:56:34 --> Input Class Initialized
INFO - 2018-10-02 08:56:34 --> Language Class Initialized
INFO - 2018-10-02 08:56:34 --> Loader Class Initialized
INFO - 2018-10-02 08:56:34 --> Helper loaded: url_helper
INFO - 2018-10-02 08:56:34 --> Helper loaded: common_helper
INFO - 2018-10-02 08:56:34 --> Database Driver Class Initialized
INFO - 2018-10-02 08:56:34 --> Helper loaded: form_helper
INFO - 2018-10-02 08:56:34 --> Form Validation Class Initialized
DEBUG - 2018-10-02 08:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 08:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 08:56:34 --> Controller Class Initialized
INFO - 2018-10-02 08:56:34 --> Model "products_mod" initialized
INFO - 2018-10-02 08:56:35 --> File loaded: H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php
INFO - 2018-10-02 08:56:35 --> Final output sent to browser
DEBUG - 2018-10-02 08:56:35 --> Total execution time: 0.2480
INFO - 2018-10-02 17:46:49 --> Config Class Initialized
INFO - 2018-10-02 17:46:49 --> Hooks Class Initialized
DEBUG - 2018-10-02 17:46:49 --> UTF-8 Support Enabled
INFO - 2018-10-02 17:46:49 --> Utf8 Class Initialized
INFO - 2018-10-02 17:46:49 --> URI Class Initialized
DEBUG - 2018-10-02 17:46:49 --> No URI present. Default controller set.
INFO - 2018-10-02 17:46:49 --> Router Class Initialized
INFO - 2018-10-02 17:46:49 --> Output Class Initialized
INFO - 2018-10-02 17:46:49 --> Security Class Initialized
DEBUG - 2018-10-02 17:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 17:46:50 --> Input Class Initialized
INFO - 2018-10-02 17:46:50 --> Language Class Initialized
INFO - 2018-10-02 17:46:50 --> Loader Class Initialized
INFO - 2018-10-02 17:46:50 --> Helper loaded: url_helper
INFO - 2018-10-02 17:46:50 --> Helper loaded: common_helper
INFO - 2018-10-02 17:46:50 --> Database Driver Class Initialized
INFO - 2018-10-02 17:46:50 --> Helper loaded: form_helper
INFO - 2018-10-02 17:46:50 --> Form Validation Class Initialized
DEBUG - 2018-10-02 17:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 17:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 17:46:50 --> Controller Class Initialized
INFO - 2018-10-02 17:46:50 --> Config Class Initialized
INFO - 2018-10-02 17:46:50 --> Hooks Class Initialized
DEBUG - 2018-10-02 17:46:50 --> UTF-8 Support Enabled
INFO - 2018-10-02 17:46:50 --> Utf8 Class Initialized
INFO - 2018-10-02 17:46:50 --> URI Class Initialized
INFO - 2018-10-02 17:46:50 --> Router Class Initialized
INFO - 2018-10-02 17:46:50 --> Output Class Initialized
INFO - 2018-10-02 17:46:50 --> Security Class Initialized
DEBUG - 2018-10-02 17:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 17:46:50 --> Input Class Initialized
INFO - 2018-10-02 17:46:50 --> Language Class Initialized
INFO - 2018-10-02 17:46:50 --> Loader Class Initialized
INFO - 2018-10-02 17:46:50 --> Helper loaded: url_helper
INFO - 2018-10-02 17:46:50 --> Helper loaded: common_helper
INFO - 2018-10-02 17:46:50 --> Database Driver Class Initialized
INFO - 2018-10-02 17:46:50 --> Helper loaded: form_helper
INFO - 2018-10-02 17:46:50 --> Form Validation Class Initialized
DEBUG - 2018-10-02 17:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 17:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 17:46:51 --> Controller Class Initialized
INFO - 2018-10-02 17:46:51 --> Model "users_mod" initialized
INFO - 2018-10-02 17:46:51 --> File loaded: H:\xampp\htdocs\onlinesylhet\admin\application\views\login.php
INFO - 2018-10-02 17:46:51 --> Final output sent to browser
DEBUG - 2018-10-02 17:46:51 --> Total execution time: 0.7251
INFO - 2018-10-02 17:46:58 --> Config Class Initialized
INFO - 2018-10-02 17:46:58 --> Hooks Class Initialized
DEBUG - 2018-10-02 17:46:58 --> UTF-8 Support Enabled
INFO - 2018-10-02 17:46:58 --> Utf8 Class Initialized
INFO - 2018-10-02 17:46:58 --> URI Class Initialized
INFO - 2018-10-02 17:46:58 --> Router Class Initialized
INFO - 2018-10-02 17:46:58 --> Output Class Initialized
INFO - 2018-10-02 17:46:58 --> Security Class Initialized
DEBUG - 2018-10-02 17:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 17:46:58 --> Input Class Initialized
INFO - 2018-10-02 17:46:58 --> Language Class Initialized
INFO - 2018-10-02 17:46:58 --> Loader Class Initialized
INFO - 2018-10-02 17:46:58 --> Helper loaded: url_helper
INFO - 2018-10-02 17:46:58 --> Helper loaded: common_helper
INFO - 2018-10-02 17:46:58 --> Database Driver Class Initialized
INFO - 2018-10-02 17:46:58 --> Helper loaded: form_helper
INFO - 2018-10-02 17:46:58 --> Form Validation Class Initialized
DEBUG - 2018-10-02 17:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 17:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 17:46:58 --> Controller Class Initialized
INFO - 2018-10-02 17:46:58 --> Model "users_mod" initialized
INFO - 2018-10-02 17:46:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-02 17:46:58 --> Config Class Initialized
INFO - 2018-10-02 17:46:59 --> Hooks Class Initialized
DEBUG - 2018-10-02 17:46:59 --> UTF-8 Support Enabled
INFO - 2018-10-02 17:46:59 --> Utf8 Class Initialized
INFO - 2018-10-02 17:46:59 --> URI Class Initialized
INFO - 2018-10-02 17:46:59 --> Router Class Initialized
INFO - 2018-10-02 17:46:59 --> Output Class Initialized
INFO - 2018-10-02 17:46:59 --> Security Class Initialized
DEBUG - 2018-10-02 17:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 17:46:59 --> Input Class Initialized
INFO - 2018-10-02 17:46:59 --> Language Class Initialized
INFO - 2018-10-02 17:46:59 --> Loader Class Initialized
INFO - 2018-10-02 17:46:59 --> Helper loaded: url_helper
INFO - 2018-10-02 17:46:59 --> Helper loaded: common_helper
INFO - 2018-10-02 17:46:59 --> Database Driver Class Initialized
INFO - 2018-10-02 17:46:59 --> Helper loaded: form_helper
INFO - 2018-10-02 17:46:59 --> Form Validation Class Initialized
DEBUG - 2018-10-02 17:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 17:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 17:46:59 --> Controller Class Initialized
INFO - 2018-10-02 17:46:59 --> File loaded: H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php
INFO - 2018-10-02 17:46:59 --> Final output sent to browser
DEBUG - 2018-10-02 17:46:59 --> Total execution time: 0.6981
INFO - 2018-10-02 17:47:02 --> Config Class Initialized
INFO - 2018-10-02 17:47:02 --> Hooks Class Initialized
DEBUG - 2018-10-02 17:47:02 --> UTF-8 Support Enabled
INFO - 2018-10-02 17:47:02 --> Utf8 Class Initialized
INFO - 2018-10-02 17:47:02 --> URI Class Initialized
INFO - 2018-10-02 17:47:03 --> Router Class Initialized
INFO - 2018-10-02 17:47:03 --> Output Class Initialized
INFO - 2018-10-02 17:47:03 --> Security Class Initialized
DEBUG - 2018-10-02 17:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 17:47:03 --> Input Class Initialized
INFO - 2018-10-02 17:47:03 --> Language Class Initialized
INFO - 2018-10-02 17:47:03 --> Loader Class Initialized
INFO - 2018-10-02 17:47:03 --> Helper loaded: url_helper
INFO - 2018-10-02 17:47:03 --> Helper loaded: common_helper
INFO - 2018-10-02 17:47:03 --> Database Driver Class Initialized
INFO - 2018-10-02 17:47:03 --> Helper loaded: form_helper
INFO - 2018-10-02 17:47:03 --> Form Validation Class Initialized
DEBUG - 2018-10-02 17:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 17:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 17:47:03 --> Controller Class Initialized
INFO - 2018-10-02 17:47:03 --> File loaded: H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php
INFO - 2018-10-02 17:47:03 --> Final output sent to browser
DEBUG - 2018-10-02 17:47:03 --> Total execution time: 0.9666
INFO - 2018-10-02 17:47:07 --> Config Class Initialized
INFO - 2018-10-02 17:47:07 --> Hooks Class Initialized
DEBUG - 2018-10-02 17:47:07 --> UTF-8 Support Enabled
INFO - 2018-10-02 17:47:07 --> Utf8 Class Initialized
INFO - 2018-10-02 17:47:07 --> URI Class Initialized
INFO - 2018-10-02 17:47:07 --> Router Class Initialized
INFO - 2018-10-02 17:47:07 --> Output Class Initialized
INFO - 2018-10-02 17:47:07 --> Security Class Initialized
DEBUG - 2018-10-02 17:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 17:47:07 --> Input Class Initialized
INFO - 2018-10-02 17:47:07 --> Language Class Initialized
INFO - 2018-10-02 17:47:07 --> Loader Class Initialized
INFO - 2018-10-02 17:47:07 --> Helper loaded: url_helper
INFO - 2018-10-02 17:47:07 --> Helper loaded: common_helper
INFO - 2018-10-02 17:47:07 --> Database Driver Class Initialized
INFO - 2018-10-02 17:47:08 --> Helper loaded: form_helper
INFO - 2018-10-02 17:47:08 --> Form Validation Class Initialized
DEBUG - 2018-10-02 17:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 17:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 17:47:08 --> Controller Class Initialized
INFO - 2018-10-02 17:47:08 --> Model "products_mod" initialized
INFO - 2018-10-02 17:47:08 --> File loaded: H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php
INFO - 2018-10-02 17:47:08 --> Final output sent to browser
DEBUG - 2018-10-02 17:47:08 --> Total execution time: 0.7298
INFO - 2018-10-02 17:47:10 --> Config Class Initialized
INFO - 2018-10-02 17:47:10 --> Hooks Class Initialized
DEBUG - 2018-10-02 17:47:10 --> UTF-8 Support Enabled
INFO - 2018-10-02 17:47:10 --> Utf8 Class Initialized
INFO - 2018-10-02 17:47:10 --> URI Class Initialized
INFO - 2018-10-02 17:47:10 --> Router Class Initialized
INFO - 2018-10-02 17:47:10 --> Output Class Initialized
INFO - 2018-10-02 17:47:10 --> Security Class Initialized
DEBUG - 2018-10-02 17:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-02 17:47:10 --> Input Class Initialized
INFO - 2018-10-02 17:47:10 --> Language Class Initialized
INFO - 2018-10-02 17:47:10 --> Loader Class Initialized
INFO - 2018-10-02 17:47:10 --> Helper loaded: url_helper
INFO - 2018-10-02 17:47:10 --> Helper loaded: common_helper
INFO - 2018-10-02 17:47:10 --> Database Driver Class Initialized
INFO - 2018-10-02 17:47:10 --> Helper loaded: form_helper
INFO - 2018-10-02 17:47:10 --> Form Validation Class Initialized
DEBUG - 2018-10-02 17:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-02 17:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-02 17:47:11 --> Controller Class Initialized
INFO - 2018-10-02 17:47:11 --> Model "products_mod" initialized
INFO - 2018-10-02 17:47:11 --> File loaded: H:\xampp\htdocs\onlinesylhet\admin\application\views\main.php
INFO - 2018-10-02 17:47:11 --> Final output sent to browser
DEBUG - 2018-10-02 17:47:11 --> Total execution time: 0.9545
ERROR - 2018-10-02 17:56:16 --> Severity: Warning --> Creating default object from empty value H:\xampp\htdocs\onlinesylhet\admin\application\views\products\product_form.php 17
ERROR - 2018-10-02 18:03:00 --> Severity: error --> Exception: Call to undefined function now() H:\xampp\htdocs\onlinesylhet\admin\application\models\products_mod.php 82
ERROR - 2018-10-02 18:03:15 --> Severity: Warning --> date() expects at least 1 parameter, 0 given H:\xampp\htdocs\onlinesylhet\admin\application\models\products_mod.php 82
ERROR - 2018-10-02 18:03:22 --> Severity: Warning --> Invalid argument supplied for foreach() H:\xampp\htdocs\onlinesylhet\admin\application\views\products\product_form.php 17
ERROR - 2018-10-02 18:03:27 --> Severity: Warning --> Invalid argument supplied for foreach() H:\xampp\htdocs\onlinesylhet\admin\application\views\products\product_form.php 17
ERROR - 2018-10-02 18:23:25 --> Severity: Warning --> date() expects at least 1 parameter, 0 given H:\xampp\htdocs\onlinesylhet\admin\application\models\products_mod.php 82
