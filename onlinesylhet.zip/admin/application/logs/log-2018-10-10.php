<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-10 18:35:34 --> Query error: Unknown column 'method_image' in 'field list' - Invalid query: INSERT INTO `delivery_methods` (`method_name`, `method_des`, `method_image`, `method_status`) VALUES ('Free Delivery', '', '', '1')
