<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-06 03:56:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 H:\xampp\htdocs\onlinesylhet\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-10-06 03:56:52 --> Unable to connect to the database
ERROR - 2018-10-06 05:13:51 --> Query error: Table 'cms.payments' doesn't exist - Invalid query: select payments.* from payments  where 1 order by payment_name  asc 
ERROR - 2018-10-06 05:13:53 --> Query error: Table 'cms.payments' doesn't exist - Invalid query: select payments.* from payments  where 1 order by payment_name  asc 
ERROR - 2018-10-06 05:15:00 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-10-06 05:15:02 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-10-06 05:24:26 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-10-06 05:24:30 --> Could not find the language line "form_validation_check_valid_amount"
ERROR - 2018-10-06 05:29:34 --> Could not find the language line "form_validation_check_valid_amount"
